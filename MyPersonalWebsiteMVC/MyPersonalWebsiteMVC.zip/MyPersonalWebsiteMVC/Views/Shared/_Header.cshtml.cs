using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyPersonalWebsiteMVC.Views.Shared
{
    public class _HeaderModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
