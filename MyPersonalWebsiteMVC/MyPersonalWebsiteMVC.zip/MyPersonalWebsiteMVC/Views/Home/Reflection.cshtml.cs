using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyPersonalWebsiteMVC.Views.Home
{
    public class ReflectionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
