using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyPersonalWebsiteMVC.Views.Home
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
